/**
 * @author gomi_ningen
 */

var GOCHIUSA_URL = "http://www.nicovideo.jp/watch/1397552685";
if(location.href != GOCHIUSA_URL)
  location.href = GOCHIUSA_URL;

