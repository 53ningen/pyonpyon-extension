/**
 * @author gomi_ningen
 */

var GOCHIUSA_URL = "http://www.nicovideo.jp/watch/1444806625";
if(location.href != GOCHIUSA_URL)
  location.href = GOCHIUSA_URL;

